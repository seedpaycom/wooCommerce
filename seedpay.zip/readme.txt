=== WooCommerce Seedpay Gateway ===
Contributors: Seedpay
Tags: Seedpay
Requires at least: 4.0.0
Tested up to: 4.3
Requires PHP: 5.6
Stable tag: 1.0.0
License: GPLv3 or later License
URI: http://www.gnu.org/licenses/gpl-3.0.html

=== WooCommerce Seedpay Gateway ===

A payment gateway from Seedpay

== Important Note ==

An SSL certificate is recommended for additional safety and security.