export default {
    acceptedAndPaid: 'acceptedAndPaid',
    accepting: 'accepting',
    errored: 'errored',
    pending: 'pending',
    rejected: 'rejected',
}
