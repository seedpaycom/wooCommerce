let appConfig = {}
export default appConfig
