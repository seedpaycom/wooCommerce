describe('archivePlugin', () => {
    it('does all the archives', () => {
        require('./archivePlugin')
    })
})
