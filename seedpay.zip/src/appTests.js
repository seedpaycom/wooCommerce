import app from './app'
describe.skip('app', () => {
    var options
    beforeEach(() => {
        options = {}
    })
})
